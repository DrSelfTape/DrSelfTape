# Install Claude First 🤖 — the one-time setup (start here)

New to Claude? Do this **once**, in order, and you'll be ready to run the
auto-submitter. Takes about 15 minutes. No coding — just installing two things
and signing in.

> **What you're setting up:** Claude (the AI) + a Chrome add-on that lets Claude
> see and click inside YOUR browser, on YOUR machine. That's how it submits you
> on the casting sites without you ever sharing a password.

---

## What it costs to RUN (be clear-eyed before you start)
The kit is free. To actually run it you need two paid subscriptions:
- **Claude Pro** — $20/month. This is what powers the tool. → https://claude.ai
- **Actors Access Plus** — $9.99/month. Makes submitting with your media free. → https://www.actorsaccess.com
  *(Casting Networks users: a paid CN membership instead — the free tier can't submit.)*

**~$30/month total.** If that's not for you right now, no hard feelings — come
back when it is.

---

## Step 1 — Get a Claude account + Pro (~3 min)
1. Go to **https://claude.ai** and sign up (Google or email).
2. Click your name / **Settings → Billing** (or the "Upgrade" button).
3. Choose **Pro ($20/month)** and subscribe.
   - Pro is the tier that unlocks the Chrome tool. Free won't work.

## Step 2 — Install the Claude desktop app (~3 min)
1. Go to **https://claude.ai/download**.
2. Download the app for your computer (**Mac** or **Windows**) and install it
   like any app (open the file, drag to Applications / click through the installer).
3. Open the app and **sign in with the same account** from Step 1.

## Step 3 — Install "Claude for Chrome" (~3 min)
1. Open **Google Chrome** (if you don't have it: https://www.google.com/chrome).
2. Go to the **Chrome Web Store** and search **"Claude for Chrome"** (by Anthropic),
   or open: https://chromewebstore.google.com and search there.
3. Click **Add to Chrome → Add extension**.
4. Click the little puzzle-piece icon (top-right of Chrome), find **Claude**, and
   click the pin so it stays visible.
5. Click the Claude icon and **sign in with the same account** from Step 1.

## Step 4 — Connect the pieces (~2 min)
- Because you signed into the desktop app **and** the Chrome extension with the
  **same Claude account**, they're already linked.
- In Chrome, open the Claude side panel (click the pinned Claude icon). If it asks
  for permission to view/act on the current tab, **allow it** — that's what lets it
  drive the casting site for you.

## Step 5 — Log into your casting site (~1 min)
- In that **same Chrome**, go to **actorsaccess.com** (and/or
  **castingnetworks.com**) and **log in**. Stay logged in.
- The tool uses your existing logged-in session. You never type your casting
  password into Claude or the kit — it just clicks around the site you're already
  signed into.

---

## ✅ You're ready
Now go back to **START-HERE.md** and pick your site folder
(**1-Actors-Access** or **2-Casting-Networks**). Each has a short setup guide:
fill in 5 fields in one file, load the `.skill`, and tell Claude to run it.

## If you get stuck
- **"The extension won't sign in / says upgrade needed"** → make sure your Claude
  account is on **Pro**, not Free (Step 1).
- **"Claude can't see the casting site"** → make sure you're logged into the site
  in the **same Chrome window**, and that you allowed the extension to access the
  tab (Step 4).
- Still stuck? Email **info@drselftapes.com** — we'll walk you through it.

> Anthropic occasionally updates how these install screens look. If a button is
> named slightly differently, the idea is always the same: **paid Claude account →
> desktop app → Chrome extension → all signed into the same account.**
