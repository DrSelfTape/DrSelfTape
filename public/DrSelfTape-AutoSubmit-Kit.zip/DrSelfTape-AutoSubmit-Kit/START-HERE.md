# Dr Self Tape — Auto-Submit Kit 🎬

You never manually submit again. This kit auto-submits you to matching roles on
**both** Actors Access and Casting Networks — you just approve.

## What's inside
- **1-Actors-Access/** — the Actors Access auto-submitter. Open its README.md.
- **2-Casting-Networks/** — the Casting Networks auto-submitter. Open its SETUP.md.

Use one or both. Each folder is self-contained with its own setup guide.

## 🆕 New to Claude? Read INSTALL-CLAUDE-FIRST.md first
It walks you through installing Claude + the Chrome add-on, click by click. Do
that once, then come back here. Already set up with Claude? Skip ahead.

## What it costs
The **kit is free**. To run it you need two paid subscriptions — about **$30/month total**:
- **Claude Pro** — $20/mo (powers the tool)
- **Actors Access Plus** — $9.99/mo (makes submitting with your media free) — *or a paid Casting Networks membership*

You run it on **your** account, on **your** computer. You never share a password.

## The setup (once you have Claude installed)
1. Unzip this folder.
2. Pick a site folder, open its setup guide (README.md / SETUP.md).
3. Fill in your profile (type, filters, pay floor) in the config file.
4. Load the `.skill` into Claude, run it, and approve the matches it lines up.
5. Optional: tell Claude "run my auto-submit every morning at 8am."

## Honest note
You approve every submission — nothing goes out without your tap. Keep it that
way; it keeps your casting accounts safe and in your control.

## Now go book it
Getting the audition is the easy part now. Booking it is the tape — that's what
the Dr Self Tape app is for: casting-style notes on your self-tape before you
submit, and a reader who actually picks up. https://drselftape.app
