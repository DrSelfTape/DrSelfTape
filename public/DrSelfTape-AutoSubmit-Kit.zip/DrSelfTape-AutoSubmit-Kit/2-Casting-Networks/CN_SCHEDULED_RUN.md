# Scheduled run procedure — Casting Networks autosubmitter (template)

Read start to finish before doing anything. All actor-specific values (name, age band,
ethnicity, pay floor, market, exclusions) come from `config.yaml` — this file describes
the PROCEDURE only.

## Profile
- Use `config.yaml` `actor:` (name, nav_name, profile_id, union) and `role_filters:` (demographics, pay floor).
- Age overlap counts, but a degenerate touch at the band's min or max only = NOT enough.

## Casting Networks specifics
- CN is a **React SPA**; the Casting Billboard renders clean role text — scan with `get_page_text`, not `fetch()`.
- Role identity is **explicitly structured**:
  `RoleType / ageMin - ageMax / Gender(s) / EthnicAppearance` then `Union / Pay`.
- CN has **native filters** (Location, Role Gender, Role Age Range, Role Ethnic Appearance, Pay Preferences)
  and saved searches — use the saved search named in `scan.use_saved_search` to pre-cut the 6000+ result set.
- **Submitting requires a paid CN membership.** An "Upgrade Now" banner may appear in the nav; ignore it.
  Never attempt to upgrade or pay — that's the user's action.

## Files in the working folder (`run.workdir`)
- `processed_projects.json` — state. `submitted_roles` (never re-submit) + `rejected_roles` (never re-evaluate). Key format: `"projectId:roleId"`. Also `last_run_iso`.
- `submissions_log.csv` — schema: `ts,market,project,role,role_id,project_id,age,gender,ethnicity,pay,photo,media,source`
- `rejected_log.csv` — negative-submission memory bank. Schema: `ts,market,project,role,role_id,project_id,reason,demo`
- `config.yaml` — filter/scope reference.

## Procedure

### 1. Prep
- Confirm Chrome MCP connected and the user is logged into CN (nav shows `actor.nav_name`; if redirected to `/login/`, abort and report "not logged in to Casting Networks").
- Read `processed_projects.json`; build `SUBMITTED` and `REJECTED` sets and `last_run_iso`.
- **Permanent skip:** any `projectId:roleId` in EITHER set is skipped and never re-classified.

### 2. Scan the Casting Billboard
- Open `site.billboard_url`. Ensure the saved search / native filters are applied
  (Location = your market; Role Gender, Ethnic Appearance, Age Range, Pay per `native_filters`).
  Set per-page = `scan.per_page`, sort = newest.
- For each page up to `scan.max_pages`: `get_page_text`, then parse role cards. Stop early once you
  reach roles posted before `last_run_iso` (or older than `scan.fallback_window_hours`).

### 3. Parse role cards (from get_page_text)
Each project block looks like:
```
{ProjectName}
{Type} | {Subtype} | {AuditionMethod}
{N} Roles Fit For You
{RoleName}
{DUE TODAY | Submissions Due {date}} | Work {dates} | Posted {date}
{RoleType} / {ageMin} - {ageMax} / {Gender(s)} / {EthnicAppearance}
{Union} / {Pay}
{description...}
[Work Location: {loc}]
```
- `role_id` / `project_id`: get from the role title link (`/talent/project/{project_id}/role/{role_id}`).
  (Read the anchors via read_page/find/javascript to map each title to its URL.)
- Skip if `SUBMITTED`/`REJECTED` has `projectId:roleId`.

### 4. Filter (FINE pass — record a reason for every drop)
- **Gender:** keep per `gender_keep_if_contains`; drop per `gender_drop_if_only`.
- **Gender identities:** drop roles matching `exclude_gender_identities` unless an open token ("any gender") is present.
- **Age:** parse `ageMin-ageMax`; require a NON-degenerate overlap with `age_min`–`age_max`.
- **Ethnicity:** keep per `ethnicity_keep_if_contains`; drop specific lists with no match.
  (The role-detail "Ethnic Appearance" section sometimes lists ALL appearances even when the card says
  a specific one — trust the CARD's summary line, not the exhaustive detail list.)
- **Keyword exclusions** (description + role line): everything in `exclude_keywords`.
  Fight/stunt choreography is EXEMPT (keep).
- **Project exclusions:** `exclude_project_types` (match the project Type line) and `exclude_project_ids`.
- **Pay floor:**
  - Unpaid / "No compensation" → DROP.
  - Union-scale strings (`union_scale_keep_phrases`) → KEEP.
  - Explicit per-day rate (`$X/12`, `$X per day`, `$X/12 HRS`) → use the GUARANTEED figure:
    for a range (`$500-$1,000/12`) that is the LOWEST number, not the highest. DROP if the
    guaranteed figure is below `min_day_rate`.
  - Flat / session / buyout / weekly / hourly figure → KEEP if `flat_rates_ok`.
  - No dollar figure and not union-scale → follow `if_no_rate`.
- **Location:** drop clearly out-of-market shoots; keep in-market / metro / unspecified.
- Skip expired roles and "real people"/family-unit/external-form casts.

### 5. Submit (only if `submission.enabled: true`)
0. Cap check: at run start, count today's rows already in `submissions_log.csv`; if config
   sets a daily cap, only submit up to (cap − already-submitted-today) this run — the cap is
   per DAY, not per run.
1. Navigate directly to `{site.role_url_template}/customize-submission` for the role; wait ~`timing.page_load_wait`s.
   If the page already shows this role as "Submitted" (a previous run crashed after submitting
   but before persisting), do NOT resubmit: record it to `submitted_roles` + the log now, and move on.
2. Step 1 "Review Profile Media": all profile photos are auto-selected. Select all videos/audio if any exist.
3. If the role asks for a note (e.g. "indicate experience", "include sizes"), fill the optional note textarea; otherwise leave blank.
4. Click **Submit** (top-right) → confirm modal "Are you sure you're ready to send?" → click **"Yes, Send Response"**.
5. Success = redirect to the billboard; the role then shows "Submitted" / appears under the Submissions tab.
6. Wait `timing.between_submissions`s before the next.

### 6. Persist (after every successful submission)
- `processed_projects.json`: add `"projectId:roleId"` to `submitted_roles` (sorted); update `last_run_iso`.
- `submissions_log.csv`: append a row.
- For every NEW role dropped BY THE FILTERS: add to `rejected_roles` (permanent skip) + append a
  reasoned row to `rejected_log.csv`. ONLY filter-rejected roles go here.
- Roles that MATCHED but were not submitted for any other reason (`submission.enabled: false`
  dry run, daily cap reached, broken form) are NOT rejected — leave them out of both sets so a
  later run submits them. In a dry run, report them as "WOULD SUBMIT: …" instead.

### 7. Report
```
CN autosubmitter ran at {time}.
Scanned: {N} roles across {P} pages ({market}, newest, since {last_run})
New matches found: {M}
Submitted: {X}
Skipped/rejected: {Y}
Errors: {Z}
Total cumulative submissions: {count}
```

## Throttling
If CN throttles or a page hangs, wait `timing.throttle_backoff`s and retry once; if still failing,
stop and report what was submitted so far.
