# Setup — Casting Networks autosubmitter

One-time setup, roughly 15 minutes. Do this WITH Claude in an interactive session before scheduling anything.

## Prerequisites
- A Casting Networks talent account with a **paid membership** (the free tier cannot submit).
- The **Claude in Chrome** extension installed and connected, with an active CN login in that browser.
- Claude desktop app (Cowork) with access to a folder on your computer.

## Steps

1. **Create the working folder.** Somewhere in your connected folder, e.g. `~/Documents/cn_autosubmitter/`. Copy `config.yaml`, `CN_SCHEDULED_RUN.md`, and the two starter files (`processed_projects.json`, `submissions_log.csv`, `rejected_log.csv`) into it.

2. **Fill in `config.yaml`.** Replace every `{PLACEHOLDER}`: your name as CN shows it in the nav bar, your CN profile id (numeric id in your profile URL), your market, playable age band, gender(s), ethnic appearance(s), and minimum acceptable day rate. Review `exclude_keywords` — remove the singing/dancing blocks if you sing or dance. Set `run.workdir` to the working folder's absolute path.

3. **Edit `SKILL.md`.** Replace `{WORKDIR}` (both mentions) with the same absolute path.

4. **Create a CN saved search.** On the Casting Billboard, set the native filters to match `native_filters` in your config (Location, Role Gender, Role Age Range, Role Ethnic Appearance, Pay Preferences = Paid), save it, and put its exact name in `scan.use_saved_search`.

5. **Do a supervised test run.** Ask Claude to run the skill while you watch, with `submission.enabled: false` first (scan/filter only, no submissions). Check the rejected log — do the reasons look right for you? Tune filters as needed.

6. **Do one supervised test submission.** Pick one role you'd genuinely submit to, set `submission.enabled: true`, and let Claude submit it while you watch. Verify it appears under CN's Submissions tab.

7. **Schedule it.** Ask Claude to schedule the skill (e.g. daily at 2:30pm). Keep your CN login active in Chrome — sessions expire, and the run aborts safely if you're logged out.

## Notes
- State lives in `processed_projects.json`; a role rejected once is never re-evaluated. Delete an id from `rejected_roles` if you change filters and want it reconsidered.
- The skill never pays, upgrades, or logs in for you — those stay manual.
- Site layouts change. If runs start erroring, re-verify the submission flow supervised before trusting it again.
