# FAQ — Casting Networks Auto-Submit

## Is this allowed?

Be informed before you start. Casting Networks' Terms of Use govern how you access the site, and automated submitting sits in a gray area of any casting platform's terms. You run this on **your own account, on your own computer, in your own logged-in browser** — you never share your password with anyone, which is the safest posture — but it is still your account and your standing at stake. This is your decision to make. Keep your filters tight (so it only submits to roles you would genuinely submit to by hand), keep the daily volume to what a person would reasonably do, and read CN's current Terms of Use yourself. *This is not legal advice.*

## Do I need a paid Casting Networks membership?

Yes. The free tier cannot submit to roles. The agent will never upgrade, pay, or purchase anything for you — if it hits a paywall it skips and tells you.

## Does my computer need to be on?

For scheduled runs, yes — it drives your own Chrome, so the machine needs to be on and awake at the run time, with your CN login active. Sessions expire; if you're logged out, the run aborts safely and tells you instead of doing anything.

## What does it never do?

It never logs in for you, never pays for anything, never changes your profile, and never submits to a role your filters rejected. Every submission and every rejection is written to a log you can read (`submissions_log.csv`, `rejected_log.csv`) — review them whenever you like.

## What if it makes a mistake?

Submissions on CN can't be un-sent, which is why setup walks you through a no-submission dry run first, then ONE supervised submission, before you ever schedule it. If the rejected log shows the filters judging wrong, tune `config.yaml` and dry-run again. Start with a low daily cap.

## What if it stops working?

Casting Networks updates their site sometimes; automation built on a site's layout eventually needs maintenance. If runs start erroring, stop scheduling and re-verify with a supervised run. Updates come through the same place you got the kit.
