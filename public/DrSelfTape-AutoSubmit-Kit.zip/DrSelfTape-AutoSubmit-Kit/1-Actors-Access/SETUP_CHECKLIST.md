# Dr Self Tape — Auto-Submit · Setup Checklist

Work top to bottom. The whole thing takes about 20 minutes the first time.
Two paid accounts are required — **each is under $25/month** (about **$30/mo combined**).

---

## Part 1 — Accounts & apps you need (one-time)

- [ ] **Actors Access Plus** — $9.99/mo (or $68/year). This is what makes submitting *with your media* free. → actorsaccess.com
- [ ] **Your AA profile is live** — at least one headshot and one SlateShot uploaded (media upload fees are separate and one-time-ish)
- [ ] **Claude Pro** — $20/mo (or $17/mo billed annually). Includes Cowork, which runs the tool. → claude.com/pricing
- [ ] **Claude desktop app** installed and signed in (macOS or Windows)
- [ ] **"Claude in Chrome" extension** installed and connected to your Claude desktop app
- [ ] **Google Chrome**, with you **logged into actorsaccess.com** (stay logged in)
- [ ] A **computer that's on and awake** at the times you want it to run

> Combined cost: **~$30/month** (AA Plus $9.99 + Claude Pro $20). Each well under $25.

---

## Part 2 — Install the tool (one-time)

- [ ] **Download** the kit and unzip it to a folder you'll keep (e.g. Documents/DrSelfTape-AutoSubmit)
- [ ] **Install the agent**: double-click `DrSelfTape-AutoSubmit.skill` (or in Claude desktop go to **Settings → Capabilities → add skill**)
- [ ] **Open `CLIENT_PROFILE.yaml`** in any text editor, fill in the 5 fields, and **save it inside the kit folder**

---

## Part 3 — First run

- [ ] In Chrome, confirm you're logged into Actors Access (you should see your name + "Sign out")
- [ ] In Claude desktop, confirm the Claude-in-Chrome extension shows **connected**
- [ ] Tell Claude: **"Run my Dr Self Tape auto-submit"**
- [ ] When it finishes, open `submissions_log.csv` and confirm the roles look right for you
- [ ] Tweak `CLIENT_PROFILE.yaml` if anything was off, and run once more

---

## Part 4 — Put it on autopilot

- [ ] Tell Claude: **"Run my auto-submit every morning at 8am"** (pick your time)
- [ ] Leave your computer on/awake at that time
- [ ] Check `submissions_log.csv` whenever you want to see what went out

**To pause it:** tell Claude "stop my auto-submit schedule," or delete the scheduled task in Settings.

---

### Quick reference — what each file does
| File | What it's for |
|---|---|
| `CLIENT_PROFILE.yaml` | Your settings. The only file you edit. |
| `DrSelfTape-AutoSubmit.skill` | The agent. Install once. |
| `processed_projects.json` | Auto-created. Remembers what it already submitted (no double-submits). |
| `submissions_log.csv` | Auto-created. Your running record of everything submitted. |
| `ONBOARDING_FAQ.md` | Answers to common questions. |

> Heads up: the kit ships capped at **15 submissions/day** for your first weeks so it doesn't over-submit. Raise it in `CLIENT_PROFILE.yaml` once you trust the matches.

---
Stuck on any step? Email **info@drselftapes.com** — Dr Self Tape.
