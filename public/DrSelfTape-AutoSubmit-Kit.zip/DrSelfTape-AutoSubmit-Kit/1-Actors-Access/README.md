# Dr Self Tape — Auto-Submit Kit

Auto-submits you to new Actors Access roles that fit your casting type, while you
sleep. You set your profile once; it does the rest.

## Start here
1. Read **SETUP_CHECKLIST.md** and tick off the requirements (Actors Access Plus +
   Claude Pro — each under $25/mo).
2. Install **DrSelfTape-AutoSubmit.skill** in Claude desktop (double-click it, or
   Settings → Capabilities).
3. Fill in **CLIENT_PROFILE.yaml** (5 fields) and save it in this folder.
4. Tell Claude: *"Run my Dr Self Tape auto-submit."*
5. Like it? *"Run it every morning at 8am."*

Questions → **ONBOARDING_FAQ.md**

## What's in this folder
- `CLIENT_PROFILE.yaml` — your settings (the only file you edit)
- `DrSelfTape-AutoSubmit.skill` — the agent (install once)
- `SETUP_CHECKLIST.md` — requirements + step-by-step
- `ONBOARDING_FAQ.md` — common questions
- `processed_projects.json` / `submissions_log.csv` — auto-created records

## Two honest notes
- It runs on **your** Actors Access account, on **your** computer. You never share a
  password. Automated submitting is a gray area in AA's Terms of Use — read them and
  keep your filters tight. (Not legal advice; see the FAQ.)
- For scheduled runs your computer must be **on and awake** at the run time.

Need help? **info@drselftapes.com**

— Powered by Dr Self Tape · info@drselftapes.com
