# Dr Self Tape — Auto-Submit · Onboarding FAQ

### What does this actually do?
Each time it runs, it scans the newest Actors Access breakdowns in your market, keeps only the roles that fit **your** profile (gender, playing age, look, union status), and submits you to each one with your headshot and all your SlateShots. It remembers what it already sent, so it never double-submits.

### Is this allowed? Will my account get banned?
Be informed before you start. Actors Access's Terms of Use restrict use of the site to "purposes specifically authorized by Breakdown" and prohibit sharing logins or giving others access to your submissions. You run this on **your own account, on your own computer** — you are never sharing your password with anyone — which is the safest posture, but automated submitting still sits in a gray area of their terms and could affect your account standing. This is your decision to make. Keep your filters tight (so you're only submitting to roles you'd genuinely submit to by hand), don't run it more often than a person reasonably would, and read AA's current Terms of Use yourself. *This is not legal advice.*

### How much does it cost?
Two subscriptions, **each under $25/month**: Actors Access Plus ($9.99/mo, makes media submissions free) and Claude Pro ($20/mo, runs the tool). About **$30/month total**.

### Do I need to be technical?
No. You fill in 5 fields in one file (`CLIENT_PROFILE.yaml`), then tell Claude to run it. That's it.

### Does my computer have to stay on?
For **scheduled** runs, yes — it drives your own Chrome, so the computer needs to be on and awake at the run time. You can also just run it manually whenever you sit down at your machine.

### Will it submit me to roles I'm wrong for?
It filters reliably on age range, ethnicity/look, gender, and union status, because Actors Access lists those in a structured line on every role. Finer "look" cues (height, build, hair, vibe) live in free-text descriptions it can't read reliably — so review your `submissions_log.csv` for the first few runs and tighten your profile if needed.

### Will it spam everything on day one?
No. The kit ships with a **daily cap of 15 submissions** so your first runs stay sane while you confirm the matches look right. Once you trust it, raise or remove the cap in `CLIENT_PROFILE.yaml` (`daily_submission_cap`).

### What photo and media does it use?
Your **primary (default) AA headshot** and **all of your SlateShots**, every time. You can pin a specific photo by putting its ID number in the `photo:` field instead of `primary`.

### How do I change who it submits me for?
Edit `CLIENT_PROFILE.yaml` and save. The next run uses the new settings immediately.

### Can it run while I sleep?
Yes — schedule it (e.g. "every morning at 8am") and leave your computer awake. It'll have your submissions in before you wake up.

### Does it ever submit to the same role twice?
No. It keeps a `processed_projects.json` list and skips anything already submitted.

### A submission didn't go through — what happened?
Occasionally a specific role's submission form is broken on Actors Access's side (the window opens blank). The tool retries, and if it's still broken it skips that one role and moves on — it'll try again on the next run in case AA fixes it. Everything that succeeded is in your log.

### How do I turn it off?
Tell Claude "stop my auto-submit schedule," or remove the scheduled task in Claude's settings. Deleting the schedule stops all automatic runs.

### Who do I contact for help?
Dr Self Tape support — **info@drselftapes.com**. Include your `submissions_log.csv` and a screenshot if something looks off, and we'll get you sorted.

---
*Dr Self Tape · info@drselftapes.com — your tape, your career, on autopilot.*
