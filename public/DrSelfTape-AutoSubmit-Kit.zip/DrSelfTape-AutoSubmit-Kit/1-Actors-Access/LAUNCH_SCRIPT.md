# Dr Self Tape — Launch / Promo Script
### "The Claude Skill every working actor needs in 2026"

Format pack for Reels / TikTok / Shorts + a longer YouTube cut. Shoot it talking-to-camera
with screen-recording B-roll of the tool running. Keep your energy up and your cuts fast.

---

## ⚡ HOOK OPTIONS (test 3, keep the winner)

1. "If you're an actor in 2026 and you're still submitting on Actors Access by hand… you're losing roles while you sleep."
2. "Casting breakdowns drop at 6am. You see them at noon. The role's already gone. Here's how I fixed that — permanently."
3. "Everyone's talking about Claude Skills for founders and marketers. Nobody's talking about the one skill that actually gets actors in the room."

---

## 🎬 SHORT-FORM SCRIPT (≈40 sec — Reels / TikTok / Shorts)

**[0:00–0:03] HOOK** — *talking to camera, fast*
> "Actor in 2026? Stop submitting on Actors Access by hand. You're losing roles while you sleep."
`ON-SCREEN: STILL SUBMITTING MANUALLY?? 😬`

**[0:03–0:10] THE PROBLEM** — *B-roll: scrolling endless breakdowns*
> "Hundreds of breakdowns a week. Most don't fit you. The ones that do? You catch them hours late — after a thousand people already submitted."
`ON-SCREEN: the role's already gone.`

**[0:10–0:20] THE TURN** — *B-roll: screen recording, the tool scanning + submitting*
> "So we built a Claude Skill for it. You set your type once — age range, look, union status, your market. Then it scans the newest breakdowns and submits you to every role you actually fit. With your headshot and all your slates."
`ON-SCREEN: set it once. ✅`

**[0:20–0:30] THE FLEX** — *B-roll: phone on nightstand, sunrise, log filling in*
> "It runs while you sleep. You wake up, open the log, and you're already submitted to the roles that matter — before most actors have had coffee."
`ON-SCREEN: submitted before you woke up.`

**[0:30–0:40] CTA**
> "It's the Dr Self Tape Auto-Submit Kit. Two cheap subscriptions, twenty-minute setup, no tech skills. Comment 'AUTO' and I'll send you the kit."
`ON-SCREEN: comment "AUTO" 👇 · Dr Self Tape`

---

## 📺 LONG-FORM SCRIPT (≈90 sec — YouTube / IG carousel VO)

**Hook (0–6s)**
> "There's a Claude Skill every working actor should have in 2026, and almost nobody's using it yet. It submits you to casting calls automatically. Let me show you."

**Why this matters (6–25s)**
> "Here's the game on Actors Access: breakdowns drop all day, casting reviews submissions in the order they come in, and the ones who submit early get seen. If you've got a survival job, a class, an audition — you're checking the site twice a day and missing the window. That's not a hustle problem. That's a timing problem."

**What it is (25–55s)** — *screen recording*
> "This is the Dr Self Tape Auto-Submit Kit. It's a Claude Skill — you install one file, fill in five things about yourself: the gender you get cast as, your playing age range, your look, your union status, and your market. Then you tell Claude to run it. It scans the newest breakdowns, keeps only the roles that match you — and submits you with your headshot and all your SlateShots. It remembers what it already sent, so it never double-submits."

**The honest part (55–72s)** — *this builds trust, don't skip it*
> "Real talk: it runs on YOUR account, on YOUR computer — you never hand your login to anyone. You set a daily cap so it stays sane. And you review the log. It's a tool that does the boring part fast, not a magic 'book every job' button. Keep your filters tight and it submits you exactly where you'd submit yourself — just hours earlier and while you're asleep."

**Cost + setup (72–82s)**
> "You need Actors Access Plus and Claude Pro — each under twenty-five bucks a month — and about twenty minutes to set up. That's it. No coding."

**CTA (82–90s)**
> "If you want the kit, it's linked below — or DM me 'AUTO.' Set it up this weekend and let it work the week for you. Dr Self Tape — your tape, your career, on autopilot."

---

## 📝 CAPTION (paste under the post)

> The Claude Skill every actor needs in 2026 🎭🤖
> Stop missing breakdowns because you saw them too late. Set your type once → get auto-submitted to every role you fit, with your headshot + slates, while you sleep.
> Runs on YOUR account. ~20-min setup. Two subs under $25/mo each. No tech skills.
> Comment "AUTO" for the kit. 👇
>
> #actorslife #actorsaccess #selftape #castingcall #workingactor #actingcareer #claudeai #aitools #actor2026 #auditiontips #drselftape

---

## 🎯 NOTES FOR THE SHOOT
- Lead with the pain (missing roles), not the tech. Actors care about being *seen*, not about AI.
- Show the log filling in — proof beats promises.
- Keep the "honest part" in the long cut. It's what separates you from spammy AI-bro content and builds trust with a skeptical acting community.
- One clear CTA per post ("AUTO"). Don't stack asks.
- Avoid promising bookings — promise *submissions* and *timing*. That's what's true, and it's enough.

— Dr Self Tape · info@drselftapes.com
